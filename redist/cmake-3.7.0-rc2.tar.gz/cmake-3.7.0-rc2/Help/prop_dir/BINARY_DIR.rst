BINARY_DIR
----------

This read-only directory property reports absolute path to the binary
directory corresponding to the source on which it is read.
